## Module <education_university_management>

#### 07.02.2024
#### Version 17.0.1.0.0
#### ADD
- Initial Commit  University Education Management

#### 01.08.2024
#### Version 17.0.1.0.1
#### UPDT
- Updated student portal template

#### 09.08.2024
#### Version 17.0.1.0.1
#### UPDT
- Updated student portal template and index 
