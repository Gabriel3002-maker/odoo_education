## Module <education_core>

#### 11.04.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Educational ERP Core

#### 15.07.2024
#### Version 17.0.1.0.1
##### UPDT
- Bug Fix-Fixed the duplication issue
