## Module <education_fee>

#### 19.02.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Educational Fee Management

#### 11.06.2024
#### Version 17.0.1.0.1
##### UPDT
- Bug Fix-Fixed issues related to fee receipts