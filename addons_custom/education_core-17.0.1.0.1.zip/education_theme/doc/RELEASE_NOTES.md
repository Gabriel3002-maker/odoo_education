## Module <education_theme>

#### 26.12.2022
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Educational ERP Theme
