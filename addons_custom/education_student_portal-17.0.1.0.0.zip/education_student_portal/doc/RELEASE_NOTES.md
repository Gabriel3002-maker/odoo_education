## Module <education_student_portal>

#### 19.10.2024
#### Version 17.0.1.0.0
##### ADD
- Initial commit for Educational Student Portal & Online Admission
