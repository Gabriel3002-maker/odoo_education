# -*- coding: utf-8 -*-
##############################################################################
# For copyright and license notices, see __openerp__.py file in root directory
##############################################################################
from . import edu_academic_training
from . import edu_enrollment
from . import edu_enrollment_line
from . import edu_evaluation
from . import edu_evaluation_line
from . import edu_marks_bulletin
from . import edu_subject
from . import edu_training_plan
from . import edu_training_plan_classroom
from . import edu_training_plan_line
from . import edu_training_plan_typology
from . import res_partner
