# -*- coding: utf-8 -*-
##############################################################################
# For copyright and license notices, see __openerp__.py file in root directory
##############################################################################
from . import wizard_customer_receipt
from . import wizard_enroll_student
from . import wizard_fill_subjects
from . import wizard_marks_bulletin
from . import wizard_migrate_student
